import React, { Component } from "react";
import "./App.css";
import ImgCard from "./components/ImgCard";
import NavBar from "./components/NavBar";
import axios from "axios";

class App extends Component {
  state = {
    images: [],
    loader: true,
    error: false,
  };
  componentDidMount() {
    axios({
      method: "GET",
      url: "https://jsonplaceholder.typicode.com/photos",
    })
      .then((res) => {
        const slicedArr = res.data.slice(0, 9);
        this.setState({
          images: slicedArr,
          loader: false,
        });
      })
      .catch((err) => {
        this.setState({
          error: true,
          loader: false,
        });
      });
  }
  handleDelete = (id) => {
    const imagesArr = [...this.state.images];
    const images = imagesArr.filter((image) => {
      return image.id !== id;
    });
    this.setState({
      images,
    });
  };
  render() {
    console.log("THIS STATE", this.state);
    return (
      <div>
        <NavBar />
        {this.state.loader ? (
          <p>Your images are loading</p>
        ) : this.state.error ? (
          <h1>Sorry something went wrong</h1>
        ) : (
          <div className="container mt-5">
            <div className="row gridrow">
              {this.state.images.map((image) => {
                return (
                  <div className="col-sm-4 col-lg-4 col-md-4" key={image.id}>
                    <ImgCard
                      key={image.id}
                      image={image}
                      deleteImage={this.handleDelete}
                    />
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    );
  }
}

export default App;
