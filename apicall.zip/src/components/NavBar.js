import React, { Component } from "react";

class NavBar extends Component {
  render() {
    return (
      <nav className="navbar navbar-expand-sm bg-dark navbar-dark">
        <ul className="navbar-nav">
          <li className="nav-item active">
            <div className="nav-link" href="#">
              Layout
            </div>
          </li>
          <li className="nav-item">
            <div className="nav-link" href="#">
              About
            </div>
          </li>
          <li className="nav-item">
            <div className="nav-link" href="#">
              Service
            </div>
          </li>
          <li className="nav-item">
            <div className="nav-link" href="#">
              Contact
            </div>
          </li>
        </ul>
      </nav>
    );
  }
}

export default NavBar;
