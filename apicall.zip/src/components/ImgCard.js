import React, { Component } from "react";

class ImgCard extends Component {
  render() {
    const { id } = this.props.image;
    console.log("IMAGE INSIDE CARD", id);
    return (
      <div className="card">
        <img
          className="card-img-top"
          src={this.props.image.url}
          alt="something"
        />
        <div className="card-body">
          <h5 className="card-title">{this.props.image.title}</h5>
          <div
            className="btn btn-danger"
            onClick={() => this.props.deleteImage(id)}
          >
            Delete
          </div>
        </div>
      </div>
    );
  }
}

export default ImgCard;
